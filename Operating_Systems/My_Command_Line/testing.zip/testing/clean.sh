rm *.o
rm smash